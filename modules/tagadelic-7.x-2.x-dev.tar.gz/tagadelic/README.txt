The master branch is intentionally empty. Please check out the branch which
corresponds to your Drupal version (e.g. '7.x-1.x').
