Creates a Issuu PHP Stream Wrapper for Resource and implements the various
formatter and file listing hooks in the Media module.
Integrate online magazines from issuu.com in your media-library

Installation
------------
Make sure you installed the dependent modules:
-Media Internet Sources
Which depends on Media
-Install as usual from modules page, or install with drush. 

This module is tested with Media V1. Media V2 is untested. 
