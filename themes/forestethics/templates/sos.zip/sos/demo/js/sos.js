$(function() {
    
  var img2 = $("span[data-src='images/bgnew2.png']");
  $(img2).attr('id','start-compass');

  var scrollTop = $(window).scrollTop(),  
  elementOffset = $('#sections').offset().top,
  distance      = (elementOffset - scrollTop);

  $(document).scroll(function () {
      var y = $(this).scrollTop();
      if (y > distance) {
        $('#compass-bottom').fadeIn(); // in middle of page, all compasses, all the time   
        
        if ($(document).height() <= ($(window).height() + $(window).scrollTop())) {
          $('#compass-full').fadeOut(); // at bottom of page, no big compass
          $('#action-bubbles a').fadeIn();
        } else{
          $('#compass-full').fadeIn(); // in middle of page, all compasses, all the time
          $('#action-bubbles a').fadeOut();
        }
      } else { //@ top of page, no compasses
          $('#compass-full').fadeOut();
          $('#compass-bottom').fadeOut();
      }
      
  });
  
	// scroll body to 0px on click
	$('#home').click(function () {
		$('body,html').animate({
			scrollTop: 0
		}, 2000);
		return false;
	});  

  $(".image-swap").hover(
    function(){this.src = this.src.replace("_off","_on");},
    function(){this.src = this.src.replace("_on","_off");
  });
  
  $('#header-drawer').click(function() {
    $('#header-right').slideToggle('slow', function() {
      if($(this).is(":hidden")) {
        $('#header-drawer strong').html('&darr;');
      } else{
        $('#header-drawer strong').html('&uarr;');    
      }
    });
  });
/*
 $.scrollingParallax('../images/tanker.png', {
        staticSpeed : 1.7,
        loopIt : false,
        staticScrollLimit : false,
        bgHeight: '220%',
        disableIE6 : true
    });
*/    
});